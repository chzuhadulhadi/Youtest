import MailingPageUI from "./components/mailingList"
function MailingPageIndex(params) {
    return(
        <MailingPageUI />
    )
}
export default MailingPageIndex